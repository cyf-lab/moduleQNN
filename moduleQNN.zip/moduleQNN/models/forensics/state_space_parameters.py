output_states = 6                                                                         # Number of Classes
image_size = 32                                                                             # Size of images before they enter network (or smallest dimension of image)

layer_limit = 9                                                                          # Max number of layers

# Transition Options                                                # Choices for [kernel size, stride] for a max pooling layer
max_fc = 1                                                                                  # Maximum number of fully connected layers (excluding final FC layer for softmax output)
possible_fc_sizes = [i for i in [256, 128] if i >= output_states]                      # Possible number of neurons in a fully connected layer

possible_FEBlock_ids = [1, 2, 3, 4, 5]
possible_TBlock_ids = [1, 2, 3, 4]
possible_CBlock_ids = [1, 2]

allow_initial_pooling = False                                                               # Allow pooling as the first layer
init_utility = 0.3                                                                          # Set this to around the performance of an average model. It is better to undershoot this
allow_consecutive_pooling = False                                                           # Allow a pooling layer to follow a pooling layer

conv_padding = 'SAME'                                                                       # set to 'SAME' (recommended) to pad convolutions so input and output dimension are the same
                                                                                            # set to 'VALID' to not pad convolutions

batch_norm = False                                                                          # Add batchnorm after convolution before activation

epsilon_schedule = [[1.0, 400],
                    [0.9, 40],
                    [0.8, 40],
                    [0.7, 40],
                    [0.6, 60],
                    [0.5, 60],
                    [0.4, 60],
                    [0.3, 60],
                    [0.2, 60],
                    [0.1, 60]]

# Q-Learning Hyper parameters
learning_rate = 0.01                                                                        # Q Learning learning rate (alpha from Equation 3)
discount_factor = 1.0                                                                       # Q Learning discount factor (gamma from Equation 3)
replay_number = 20                                                                         # Number trajectories to sample for replay at each iteration

