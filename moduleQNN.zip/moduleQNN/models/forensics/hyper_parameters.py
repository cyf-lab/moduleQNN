import state_space_parameters as ssp


MODEL_NAME = 'forensics'
NUM_CLASSES = 6                                                                    # Number of output neurons
IMAGE_SIZE=32


#Batch Queue parameters
TRAIN_BATCH_SIZE = 128                                                              # Batch size for training
NUM_EXAMPLES_PER_EPOCH_FOR_TRAIN = 108000                                           # Number of training examples
NUM_ITER_PER_EPOCH_TRAIN = 840                                                      #NUM_EXAMPLES_PER_EPOCH_FOR_TRAIN / TRAIN_BATCH_SIZE
EVAL_BATCH_SIZE = 128                                                               # Batch size for validation
NUM_EXAMPLES_PER_EPOCH_FOR_EVAL = 27000                                              # Number of validation examples
NUM_ITER_TO_TRY_LR = NUM_ITER_PER_EPOCH_TRAIN                                       # Number of iterations to try learning rate (based on ACC_THRESHOLD)
                                                                                    # Please make an integer multiple of NUM_ITER_PER_EPOCH_TRAIN

TEST_INTERVAL_EPOCHS = 1                                                            # Num epochs to test on, should really always be 1

MAX_EPOCHS = 20                                                                     # Max number of epochs to train model
MAX_STEPS = 20 * NUM_ITER_PER_EPOCH_TRAIN



#Training Parameters
OPTIMIZER = 'Adam'                                                                   # Optimizer (should be in caffe format string)

# Learning Rate
INITIAL_LEARNING_RATES = 0.001                                                       # List of initial learning rates to try before giving up on model

# Print every?
DISPLAY_EPOCHS = TEST_INTERVAL_EPOCHS                                                # Number of batches to print between
SAVE_EPOCHS = MAX_EPOCHS                                                                     # Number of epochs between snapshots

MIRROR = True                                                                       # Randomly mirror images during training
CROP = False                                                                        # Randomly Crop input images to final image size
GCN_APPROX = False                                                                  # subtract 128 and scale
#Train files
TRAIN_FILE =  'forensic_data/train_data.txt'                                        # Path to training lmdb file -- YOU NEED TO CHANGE THIS
TEST_FILE = 'forensic_data/val_data.txt'                                            # Path to validation lmdb file -- YOU NEED TO CHANGE THIS

CAFFE_ROOT = '/HDD/program/caffe/'                                                      # Path to caffe root directory -- YOU NEED TO CHANGE THIS

# For training caffe checkpoints
CHECKPOINT_DIR = '/HDD/trained_models/' + MODEL_NAME                                     # Path to where model snapshots are saved
