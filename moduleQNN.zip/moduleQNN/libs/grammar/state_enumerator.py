import math
import numpy as np
from operator import itemgetter


class State:
    def __init__(self,
                 block_type=None,
                 block_depth=None,
                 block_id=None,
                 state_list=None):
        if not state_list:
            self.block_type = block_type
            self.block_depth = block_depth
            self.block_id = block_id

        else:
            self.block_type = state_list[0]
            self.block_depth = state_list[1]
            self.block_id = state_list[2]

    def as_tuple(self):
        return (self.block_type,
                self.block_depth,
                self.block_id)
    def as_list(self):
        return list(self.as_tuple())
    def copy(self):
        return State(self.block_type,
                     self.block_depth,
                     self.block_id)

class StateEnumerator:
    '''Class that deals with:
            Enumerating States (defining their possible transitions)

    '''
    def __init__(self, state_space_parameters):
        # Limits
        self.ssp = state_space_parameters
        self.layer_limit = state_space_parameters.layer_limit

        self.output_states = state_space_parameters.output_states 

    def enumerate_state(self, state, q_values):

        actions = []


        if state.block_type != 'CBlock':


            if state.block_depth < self.layer_limit:

                if (state.block_type in ['start']):
                    for id in self.ssp.possible_FEBlock_ids:
                        actions += [State(block_type='FEBlock',
                                            block_depth=state.block_depth + 1,
                                            block_id=id)]

                if (state.block_type in ['TBlock']):
                    if state.block_depth < self.layer_limit-1:
                        for id in self.ssp.possible_FEBlock_ids:
                            actions += [State(block_type='FEBlock',
                                                block_depth=state.block_depth + 1,
                                                block_id=id)]
                    for id in self.ssp.possible_CBlock_ids:
                        actions += [State(block_type='CBlock',
                                          block_depth=state.block_depth + 1,
                                          block_id=id)]

                if (state.block_type in ['FEBlock']):
                    for id in self.ssp.possible_TBlock_ids:
                        actions += [State(block_type='TBlock',
                                            block_depth=state.block_depth + 1,
                                            block_id=id)]



        # Add states to transition and q_value dictionary


        q_values[state.as_tuple()] = {'actions': [self.bucket_state_tuple(to_state.as_tuple()) for to_state in actions],
                                      'utilities': [self.ssp.init_utility for i in range(len(actions))]}
        return q_values        

    def transition_to_action(self, to_state):
        action = to_state.copy()
        return action

    def state_action_transition(self, action):
        to_state = action.copy()
        return to_state

    def bucket_state_tuple(self, state):
        bucketed_state = State(state_list=state).copy()
        return bucketed_state.as_tuple()

    def bucket_state(self, state):
        bucketed_state = state.copy()
        return bucketed_state

