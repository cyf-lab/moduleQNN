caffe_root = '/HDD/program/caffe/'
import sys
sys.path.insert(0, caffe_root + 'python')
from caffe import layers as L,params as P
import caffe


#### Define block structure #####

#### example ####
def FEBlock(input,id, channel):

    if id == 1:
        conv = L.Convolution(input, num_output=channel, kernel_size=3, pad=1, stride=1,
                             weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                             param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
        conv1 = L.Convolution(conv, num_output=channel, kernel_size=3, pad=1, stride=1,
                              weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                              param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
        bn_conv1 = L.BatchNorm(conv1, use_global_stats=False, in_place=True,
                               batch_norm_param=dict(moving_average_fraction=0.05))
        FEBlock_one = L.ReLU(bn_conv1, in_place=True)

    return FEBlock_one


def TBlock(input, id, num_output,pool_size, pool_stride):
    if id == 1:
        conv = L.Convolution(input, num_output=num_output, kernel_size=1, pad=0, stride=1,
                             weight_filler=dict(type='gaussian', std=float('%.2f' % 0.01)),
                             param=[dict(lr_mult=1, decay_mult=0)], bias_term=False)
        bn_conv = L.BatchNorm(conv, use_global_stats=False, in_place=True,
                              batch_norm_param=dict(moving_average_fraction=0.05))
        relu = L.ReLU(bn_conv, in_place=True)
        TBlock_one = L.Pooling(relu, pool=P.Pooling.MAX, pad=0, kernel_size=pool_size, stride=pool_stride)
    return TBlock_one


def CBlock(input,id, class_num):
    if id == 1:
        pool = L.Pooling(input, pool=P.Pooling.AVE, global_pooling=True)
        CBlock_one = L.InnerProduct(pool, num_output=class_num, weight_filler=dict(type='xavier'),
                            bias_filler={"type": "constant"})
    return CBlock_one