import math
import numpy as np
import os
import sys
import creat_block as cre
# import initialize_weight as init

from libs.grammar.state_string_utils import StateStringUtils

caffe_root='/HDD/program/caffe'
import sys
sys.path.insert(0, caffe_root + 'python')
import caffe

from caffe import layers as L
from caffe import params as P
from caffe import to_proto



class Parser:
	def __init__(self, hyper_parameters, state_space_parameters):
		self.hp = hyper_parameters
		self.ssp = state_space_parameters

	def create_net(self, net_string, datapath, for_train):
		net = caffe.NetSpec()
		net.data, net.label = caffe.layers.ImageData(source=datapath, batch_size=self.hp.TRAIN_BATCH_SIZE, shuffle=True, ntop=2,
													 transform_param=dict(scale=0.00390625))

		net_code = eval(net_string)
		code_len = len(net_code)
		class_num = self.hp.NUM_CLASSES

		if code_len == 3:
			net.FEBlock_one = cre.FEBlock(net.data, net_code[0], channel)
			net.TBlock_one = cre.TBlock(net.FEBlock_one, net_code[1], num_output, pool_size, pool_stride)
			net.CBlock_one = cre.CBlock(net.TBlock_one, net_code[code_len-1], class_num)


		if for_train:
			net.loss = L.SoftmaxWithLoss(net.ip, net.label, include=dict(phase=caffe.TRAIN))
		else:
			net.loss = L.SoftmaxWithLoss(net.ip, net.label, include=dict(phase=caffe.TEST))
		net.acc = L.Accuracy(net.ip, net.label)
		return net.to_proto()

	def creat_new_layer(self,net, substr, newstr, layernum):
		net = net.replace(substr, newstr, layernum)
		return net


	def create_caffe_spec(self, net_string, netspec_path, testpro_path):
		with open(netspec_path, 'w') as f:
			net = str(self.create_net(net_string, self.hp.TRAIN_FILE, for_train=True))
			net_code = eval(net_string)
			if net_code[0] == 100:
				substr = "type: \"Convolution\""
				newstr = "type: \"Convolution\""
				net = self.creat_new_layer(net, substr, newstr, 1)

			f.write(net)



		with open(testpro_path, 'w') as f:
			net = str(self.create_net(net_string, self.hp.TEST_FILE, for_train=False))
			net_code = eval(net_string)
			# print(net_code[0])
			if net_code[0] == 100:
				substr = "type: \"Convolution\""
				newstr = "type: \"Convolution\""
				net = self.creat_new_layer(net, substr, newstr, 1)
			f.write(net)








